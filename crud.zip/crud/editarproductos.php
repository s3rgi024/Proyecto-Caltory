<?php
	if(isset($_GET['editar'])){
		$editar_id=$_GET['editar'];
	
				$consulta="SELECT * FROM productos WHERE cod_producto='$editar_id'";
				$ejecutar=mysqli_query($conex, $consulta);
				$fila=mysqli_fetch_array($ejecutar);
			   	$cp=$fila['cod_producto'];
				$nomprod =$fila['nom_producto'];
				$valorp =$fila['valor_producto'];
				$cantp =$fila['cant_prod_disp'];
				$fechaIng =$fila['fecha_ingreso_prod'];
	   
		}				
?>
<section class="form-register">
    <div class="form">
    <form method="post" action="">  
        <input  type="text" name="cp" value="<?php echo $cp;?>">
        <input  type="text" name="nomprod" value="<?php echo $nomprod; ?>">
        <input  type="text" name="valorp" value="<?php echo $valorp; ?>">
        <input  type="text" name="cantp" value="<?php echo $cantp; ?>">
        <input  type="text" name="fechaIng" value="<?php echo $fechaIng; ?>">
        <input type="submit" name="enviar" value="actualizar">
      </form>
    </center>
    </div>
</section>	
	<?php
		if(isset($_POST['enviar'])){
			$cp =$_POST['cp'];
			$nomprod =$_POST['nomprod'];
			$valorp =$_POST['valorp'];
			$cantp =$_POST['cantp'];
			$fechaIng =$_POST['fechaIng'];

		
			$actualizar="UPDATE productos SET cod_producto='$cp', nom_producto ='$nomprod', valor_producto ='$valorp', 
			cant_prod_disp='$cantp', fecha_ingreso_prod ='$fechaIng' WHERE cod_producto='$editar_id'";
			$ejecutar =mysqli_query($conex, $actualizar);
			if ($ejecutar) {

				echo "<script>alert('Datos actualizados correctamente')</script>";
	
				mysqli_close($conex);
	
				echo "<script>window.location='crud.php'</script>";
			}
		}
		?>
</body>
</html>