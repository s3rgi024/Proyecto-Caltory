<?php
$conex = mysqli_connect("localhost","root","","caltory");

	if (!$conex) {
		echo
		  "error al conectar:";
		    } else {
		//echo "conexion ok";
	}
?>