<DOCTYPE html>
<html>
	<head>	
		<meta charset="UTF-8">
		<title>CONSULTAR</title> 
		<link rel="stylesheet" type="text/css" href="assets/stylo.css ">
		<?php
			include 'conexioon.php';
		?>			
	</head>
 <body>
	<nav class="titulo">	
	<img src="images/logo.png" alt="logo" class="logo">
    </nav>
	<h1><font size="8"> caltory</font></h1>
<br><br><br><br>	
	<!--Aqui se crea la tabla-->
		<div class="table" style="color: #;">
			<center>
    		<table>
	    		<font size="8"><tr>
	    			<td>codigo del producto</td>
                    <td>Nombre del producto </td>
					<td>Valor del Producto</td>
					<td>Cantidad de Productos </td>
   					<td>tipo de producto</td>
   					<td>Fecha de ingreso</td>
                    
    			</tr></font>
    	<!--aqui finaliza tabla-->	
		<?php
			$buscarusuarios=mysqli_query($conex,"SELECT * FROM productos") or die("fallas en la consulta");

			while ($traerusuario=mysqli_fetch_array($buscarusuarios)) {?>
				<tr>
					<td><?php echo $traerusuario['cod_producto']; ?></td>
					<td><?php echo $traerusuario['nom_producto']; ?></td>
					<td><?php echo $traerusuario['valor_producto']; ?></td>
					<td><?php echo $traerusuario['cant_prod_disp']; ?></td>
					<td><?php echo $traerusuario['fk_tipo_prod']; ?></td>
					<td><?php echo $traerusuario['fecha_ingreso_prod'];?></td>	

					<td><a href="crud.php?editar=<?php echo $traerusuario['cod_producto']; ?>"><img  src= "images/editar.png" alt = ""></a></td>
					<td><a href="crud.php?eliminar=<?php echo $traerusuario['cod_producto']; ?>"><img src="images/delete.png"alt= ""></a></td>
					<td><a href="crear.php?crear=<?php echo $traerusuario['cod_producto']; ?>"><img src="images/mas.png" alt=""></a></td>
				</tr>
			<?PHP } ?>
			</table>
			
			<?php 
				if(isset ($_GET['editar'])){
					include("editarproductos.php");
			}
			?>	

			<?php 
				if(isset ($_GET['eliminar'])){
					$borrar_id =$_GET['eliminar'];
					
					$borrar="DELETE FROM productos WHERE cod_producto='$borrar_id'";
					$ejecutar=mysqli_query($conex, $borrar);
					if($ejecutar){
						echo "<script>alert('Borrado exitoso')</script>";
						echo "<script>window.location='crud.php'</script>";
					}
				}				
			?>




</body>
</html>